from vanna.flask import VannaFlaskApp

app = Flask(__name__)

def connectToDB():
    try:
        # Set the base path for the API key file
        base_path = "./Key/"
        # Set the file path for the API key file
        filepath = f"{base_path}/API_KEY.txt"
        # Open the API key file in read mode
        with open(filepath, "r") as f:
            # Read the API key from the file and join the lines into a single string
            api_key = ' '.join(f.readlines())
            # Uncomment the following line to set the API key as an environment variable
            # os.environ["API_KEY"] = api_key

        # Set the Vanna model name
        vanna_model_name = 'gourav_vanna'
        
        # Create a VannaDefault object with the model name and API key
        vn = VannaDefault(
            model=vanna_model_name,
            api_key=api_key
        )
        
        # Set the allow_llm_to_see_data attribute to True
        vn.allow_llm_to_see_data = True  # Set the attribute after initialization
        
        # Connect to the PostgreSQL database
        vn.connect_to_postgres(
            host='db',  # Hostname for the database
            dbname='GLIEF',  # Database name
            user='postgres',  # Username for the database
            password='postgres',  # Password for the database
            port=5432  # Port number for the database
        )
        # Print a success message if the connection is successful
        print("Connection to database successful.")
        # Return the VannaDefault object
        return vn
    except Exception as e:
        # Catch any exceptions that occur during the connection process
        print(f"An error occurred while connecting to the database: {e}")
        # Return None if an error occurs
        return None    # Your database connection code here
    pass

@app.route('/')
def hello_world():
    vn = connectToDB()
    if vn:
        VannaFlaskApp(vn).run()
    else:
        print("Vanna instance is not available. Cannot proceed with asking questions.")

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=8084)
